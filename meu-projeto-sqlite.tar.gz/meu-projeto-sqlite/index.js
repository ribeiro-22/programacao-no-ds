const DatabaseAccess = require(&#39;./databaseAccess&#39;);
const db = new DatabaseAccess(&#39;./meuBanco.db&#39;);
async function testar() {
await db.executarComando(&#39;CREATE TABLE IF NOT EXISTS pessoas (id INTEGER PRIMARY KEY, nome
TEXT)&#39;);
await db.executarComando(&#39;INSERT INTO pessoas (nome) VALUES (?)&#39;, [&#39;Maria&#39;]);
const resultado = await db.executarConsulta(&#39;SELECT * FROM pessoas&#39;);
console.log(resultado);
}
testar();